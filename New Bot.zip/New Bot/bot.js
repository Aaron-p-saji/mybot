const Discord = require('discord.js');

const config = require('./config.json'); //connect with config.json

const Client = new Discord.Client({disableEveryone: true}); // create a new discord client

Client.commands = new Discord.Collection(); //New System For Commands

const fs = require('fs');

const xpfile = require('./xp.json'); //connect with xp.json file
const { dir } = require('console');
const { off } = require('process');

const prefix = "f!";

Client.aliases = new Discord.Collection();  // it creates a new function for our aliases



Client.on("ready", async () => {
    console.log(`${Client.user.username} BOT Is Up`) //client login in console
    Client.user.setActivity("f! help", {
        type: "WATCHING"
    })
});







//Command Handlers

//get into the commands folder
fs.readdirSync('./Commands/').forEach(dir =>{

    fs.readdir(`./Commands/${dir}`, (err, files) => {   //in the commands folder we are checking the catagory

        if(err) throw err;  //catch err

        var jsFile = files.filter(f => f.split(".").pop() === "js");    //checking the files extension is Javasript{.js}

        if(jsFile.length<= 0) { //If there is no comments in the file it will return
            console.log("Can't Find Any Commands");
            return;
        }

        jsFile.forEach(file => {

            var fileGet = require(`./Commands/${dir}/${file}`); //console the loaded comments
            console.log(`File ${file} was loaded`)


            try {
                Client.commands.set(fileGet.help.name, fileGet);    //lets the commands run

                fileGet.help.aliases.forEach(alias => { //it search the commands Folder it has any aliases
                    Client.aliases.set(alias, fileGet.help.name);
                })
            
            } catch (err) { //check for error
                return console.log(err);
            }
        });
    });
});







// Welcome message
Client.on("guildMemberAdd", member => {
        const welcomeChannel = member.guild.channels.cache.find(channel => channel.name === 'welcome')
        welcomeChannel.send(`Welcome! ${member} to our server hope you enjoy your stay`)
})

Client.on("guildMemberAdd", member => {
    const welcomeChannel = member.guild.channels.cache.find(channel => channel.name === '『lᴇᴀᴠᴇʀs』')
    welcomeChannel.send(`${member} just left the server`)
})







Client.on("message", async message => {
    if (message.author.Client || message.channel.type === "dm") return;

    let prefix = config.prefix;
    let messageArray = message.content.split(" ");
    let cmd = messageArray[0];
    let args = messageArray.slice(1);


    let commands = Client.commands.get(cmd.slice(prefix.length)) || Client.commands.get(Client.aliases.get(cmd.slice(prefix.length)));
    if(commands) commands.run(Client, message, args, prefix);



})









// Level System


Client.on("message", function (message) {
    if (message.author.bot) return;
    if (message.author.Client) return;
    var addXP = Math.floor(20); //when i type addXP it will randomly choose a number between 1-10   [  Math.floor(Math.random() * 10)  ]
    // lvl 1 statics
    if (!xpfile[message.author.id]) {
        xpfile[message.author.id] = {
            xp: 0,
            level: 1,
            reqxp: 100
        }
        // catch errors
        fs.writeFile("./xp.json", JSON.stringify(xpfile), function (err) {
            if (err) console.log(err)
        })
    }

    xpfile[message.author.id].xp += addXP

    if (xpfile[message.author.id].xp > xpfile[message.author.id].reqxp) {
        xpfile[message.author.id].xp -= xpfile[message.author.id].reqxp // it will subtrsct xp whenever u pass a lvl
        xpfile[message.author.id].reqxp *= 2 // XP you need to increase if level 1 is 100 xp so lvl 2 will 200 xp (multiplied by 2 [   .reqxp *= 2  ])
        xpfile[message.author.id].reqxp = Math.floor(xpfile[message.author.id].reqxp) // XP Round
        xpfile[message.author.id].level += 1 // it add 1 level when u level up

        // this code will send (" you are now level [your lvl]!") then it will delete it after 10 seconds        
        message.reply("You Are Now Level **" + xpfile[message.author.id].level + "**!")

    }
    // catch errors
    fs.writeFile("./xp.json", JSON.stringify(xpfile), function (err) {
        if (err) console / log(err)
    })

    //if someone typed in chat fanlevel it will make a embed 
    if (message.content.startsWith("f! level")) {
        let user = message.mentions.users.first() || message.author

        let embed = new Discord.MessageEmbed()
            .setTitle("Level Card")
            .setColor("GREEN")
            .addField("Level: ", xpfile[user.id].level)
            .addField("XP: ", xpfile[user.id].xp + "/" + xpfile[user.id].reqxp)
            .addField("XP Required: ", xpfile[user.id].reqxp)
        message.channel.send(embed)
    }
})

Client.login(config.token); //login to our bot