const Discord = require('discord.js');

module.exports.run = async (Client, message, args, prefix) => {
    if (!message.member.hasPermission("KICK_MEMBERS")) return message.channel.send("You Cannot Use This Command.");      // Member has Permission To Kick Another member
    const mentionedmember = message.mentions.members.first();                                                            // Member has Permission To Kick Another member THEN Command
    let reason = args.slice(1).join("")
    if(!reason) reason = "No Reason Given";
    const kickEmbed = new Discord.MessageEmbed()                                                                         //------------------------------------------------
      .setTitle(`You Were Kicked From ${message.guild.name}`)                                                               // From here EmBead Reason For Kicking and......
      .setDescription(`Reason ${reason}`)
      .setColor("#08c7c9")
      .setTimestamp()
      .setImage('https://cdn.discordapp.com/attachments/846230384148217889/862268523060920330/standard.gif')
      .setFooter(client.user.tag, client.user.displayAvatarURL());         //--------------------------------------------------------------

    const PermEmbed = new Discord.MessageEmbed()
      .setTitle("Kick Command")
      .setDescription
      ("Description: Kick A User\n \n**Error** - \nYou Need To State The User To Kick.\n \n**Remind** - \nHooks such as [] or <> must not be used when executing commands.\n \n**Usage** - \nkick <@user> [reason]\n \n**Example** -\nkick @Unni#7390 Spamming")
      .setColor("RANDOM")
      .setTimestamp()
      .setThumbnail('https://cdn.discordapp.com/attachments/845588489692905523/862184004924604436/standard.gif')
      .setAuthor(message.author.username)
      .setFooter(client.user.tag, client.user.displayAvatarURL());

      const MemEmbedNo = new Discord.MessageEmbed()
      .setTitle("Kick Command")
      .setDescription
      ("Description: Kick A User\n \n**Error** - \nThe Member Mentioned Is Not in the server.\n \n**Remind** - \nHooks such as [] or <> must not be used when executing commands.\n \n**Usage** - \nkick <@user> [reason]\n \n**Example** -\nkick @Unni#7390 Spamming")
      .setColor("RANDOM")
      .setTimestamp()
      .setThumbnail('https://cdn.discordapp.com/attachments/845588489692905523/862184004924604436/standard.gif')
      .setAuthor(message.author.username)
      .setFooter(client.user.tag, client.user.displayAvatarURL());

      const MemEmbedUn = new Discord.MessageEmbed()
      .setTitle("Kick Command")
      .setDescription
      ("Description: Kick A User\n \n**Error** - I Cannot Kick That Member.\n \n**Remind** - \nHooks such as [] or <> must not be used when executing commands.\n \n**Usage** - \nkick <@user> [reason]\n \n**Example** -\nkick @Unni#7390 Spamming")
      .setColor("RANDOM")
      .setTimestamp()
      .setThumbnail('https://cdn.discordapp.com/attachments/845588489692905523/862184004924604436/standard.gif')
      .setAuthor(message.author.username)
      .setFooter(client.user.tag, client.user.displayAvatarURL());

      const MemEmbedFa = new Discord.MessageEmbed()
      .setTitle("Kick Command")
      .setDescription
      ("Description: Kick A User\n \n**Error** - \nI Was Unable To kick The User Mentioned.\n \n**Remind** - \nHooks such as [] or <> must not be used when executing commands.\n \n**Usage** - \nkick <@user> [reason]\n \n**Example** -\nkick @Unni#7390 Spamming")
      .setColor("RANDOM")
      .setTimestamp()
      .setThumbnail('https://cdn.discordapp.com/attachments/845588489692905523/862184004924604436/standard.gif')
      .setAuthor(message.author.username)
      .setFooter(client.user.tag, client.user.displayAvatarURL());
     
      // -kick @user dm adas                                                                                             //-------------------------------------------------------
      if (!args[0]) return message.channel.send(PermEmbed);             // From Here We Checked About The User If He Is A Valid Member
      if (!mentionedmember) return message.channel.send(MemEmbedNo);
      if (!mentionedMember.kickable) return message.channel.send(MemEmbedUn)
      try{
        await mentionedmember.send(kickEmbed);
      } catch (err) {
        console.log('I Was Unable To message The Member.');
      }

      try{
        await mentionedmember.kick(reason)
      } catch(err){
        console.log(err);
        return message.channel.send(MemEmbedFa);
      }
  }
}

module.exports.help = {
    name: 'kick',
    aliases: ["Kick", "kick", "KIck", "KICk", "KICK", "kICK", "kiCK", "kicK", "KicK", "KiCk", "kIcK", "kiCk"]
};